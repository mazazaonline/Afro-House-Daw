package com.afrohouse.daw

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private lateinit var project: Project
    private lateinit var player: Player

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        project = Store.load(this) ?: Project.afroHouseDemo()
        player = Player(project)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Daw(project, player) } }
    }

    override fun onStop() {
        player.stop()
        Store.save(this, project)
        super.onStop()
    }
}

private val Amber = Color(0xFFE8A33D)
private val Panel = Color(0xFF1C1C1C)
private val SOUNDS = listOf("Kick", "Clap", "Closed Hat", "Open Hat", "Shaker", "Conga", "Rim", "Bass", "Stab")

@Composable
fun Daw(project: Project, player: Player) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var playing by remember { mutableStateOf(false) }
    var step by remember { mutableIntStateOf(-1) }
    var bar by remember { mutableIntStateOf(-1) }
    var tab by remember { mutableIntStateOf(0) }
    var importTarget by remember { mutableStateOf<Track?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            playing = player.isPlaying
            step = player.currentStep
            bar = player.currentBar
            delay(40)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val t = importTarget ?: return@rememberLauncherForActivityResult
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val data = withContext(Dispatchers.IO) { SampleLoader.load(ctx, uri) }
                t.sample = data
                t.sampleFile = null
                t.sampleLabel = uri.lastPathSegment?.substringAfterLast('/') ?: "imported"
            } catch (e: Exception) {
                Toast.makeText(ctx, "Import failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val song = project.songMode
                val bars = if (song) project.arrangement.size else 8
                withContext(Dispatchers.IO) {
                    ctx.contentResolver.openOutputStream(uri)!!.use { Exporter.renderWav(project, bars, song, it) }
                }
                Toast.makeText(ctx, "Exported $bars bars as WAV", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF111111)).statusBarsPadding().padding(horizontal = 10.dp)) {
        Row(
            Modifier.padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(onClick = { if (player.isPlaying) player.stop() else player.start() }) {
                Text(if (playing) "Stop" else "Play")
            }
            FilterChip(selected = project.songMode, onClick = { project.songMode = !project.songMode }, label = { Text("Song") })
            Text("${project.bpm.toInt()} BPM", color = Color.White, fontSize = 13.sp)
            Spacer(Modifier.weight(1f))
            OutlinedButton(onClick = { saver.launch(if (project.songMode) "afro_house_song.wav" else "afro_house_loop.wav") }) {
                Text("WAV")
            }
        }
        TabRow(selectedTabIndex = tab) {
            listOf("Pattern", "Song", "Mixer").forEachIndexed { i, s ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(s) })
            }
        }
        Box(Modifier.weight(1f).padding(top = 8.dp)) {
            when (tab) {
                0 -> PatternTab(project, step) { t -> importTarget = t; picker.launch(arrayOf("audio/*")) }
                1 -> SongTab(project, if (project.songMode) bar else -1)
                else -> MixerTab(project)
            }
        }
    }
}

@Composable
fun PatternTab(project: Project, step: Int, onImport: (Track) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Pattern", color = Color.Gray, fontSize = 12.sp)
            PATTERN_NAMES.forEachIndexed { i, n ->
                FilterChip(selected = project.editPattern == i, onClick = { project.editPattern = i }, label = { Text(n) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                for (t in project.tracks) for (k in 0 until STEPS) t.steps[project.editPattern * STEPS + k] = false
            }) { Text("Clear") }
            Box {
                OutlinedButton(onClick = { menu = true }) { Text("+ Track") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    SOUNDS.forEach { s ->
                        DropdownMenuItem(text = { Text(s) }, onClick = {
                            menu = false
                            val t = Track(s, s, Synth.byName(s))
                            t.volume = 0.7f
                            project.tracks += t
                        })
                    }
                }
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items = project.tracks, key = { it.id }) { t ->
                TrackRow(t, project.editPattern, step, { onImport(t) }, { project.tracks.remove(t) })
            }
        }
    }
}

@Composable
fun TrackRow(t: Track, pat: Int, playStep: Int, onImport: () -> Unit, onDelete: () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Panel).padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Column(Modifier.weight(1f).clickable { onImport() }) {
                Text(t.name, color = Color.White, fontSize = 14.sp)
                Text(t.sampleLabel + "  · tap to import", color = Color.Gray, fontSize = 10.sp, maxLines = 1)
            }
            FilterChip(selected = t.mute, onClick = { t.mute = !t.mute }, label = { Text("M") })
            FilterChip(selected = t.solo, onClick = { t.solo = !t.solo }, label = { Text("S") })
            TextButton(onClick = onDelete) { Text("✕", color = Color.Gray) }
        }
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            for (i in 0 until STEPS) {
                val on = t.steps[pat * STEPS + i]
                Box(
                    Modifier.weight(1f).height(30.dp).clip(RoundedCornerShape(3.dp))
                        .background(
                            when {
                                on -> Amber
                                i % 4 == 0 -> Color(0xFF3A3A3A)
                                else -> Color(0xFF2A2A2A)
                            }
                        )
                        .then(if (i == playStep) Modifier.border(1.5.dp, Color.White, RoundedCornerShape(3.dp)) else Modifier)
                        .clickable { t.steps[pat * STEPS + i] = !on }
                )
                if (i % 4 == 3 && i < STEPS - 1) Spacer(Modifier.width(3.dp))
            }
        }
    }
}

@Composable
fun SongTab(project: Project, bar: Int) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            "Tap a bar to cycle – → A → B → C → D. Switch on Song (top bar) to play this arrangement.",
            color = Color.Gray, fontSize = 12.sp
        )
        for (r in 0 until SONG_BARS / 4) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (c in 0 until 4) {
                    val idx = r * 4 + c
                    val v = project.arrangement[idx]
                    Box(
                        Modifier.weight(1f).height(64.dp).clip(RoundedCornerShape(8.dp))
                            .background(if (v < 0) Color(0xFF222222) else Amber.copy(alpha = 0.35f + 0.15f * v))
                            .then(if (idx == bar) Modifier.border(2.dp, Color.White, RoundedCornerShape(8.dp)) else Modifier)
                            .clickable { project.arrangement[idx] = if (v >= PATTERNS - 1) -1 else v + 1 },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (v < 0) "–" else PATTERN_NAMES[v], color = Color.White, fontSize = 20.sp)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { project.resetArrangement() }) { Text("Demo arrangement") }
            OutlinedButton(onClick = { for (i in 0 until SONG_BARS) project.arrangement[i] = -1 }) { Text("Clear") }
        }
        Text(
            "Demo: A = groove, B = breakdown, C = build, D = drop. Edit each pattern in the Pattern tab.",
            color = Color.Gray, fontSize = 12.sp
        )
    }
}

@Composable
fun Knob(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.width(84.dp))
        Slider(value = value, onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f).height(30.dp))
    }
}

@Composable
fun MixerTab(project: Project) {
    val ctx = LocalContext.current
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Panel).padding(8.dp)) {
                Text("Master", color = Amber, fontSize = 14.sp)
                Knob("BPM ${project.bpm.toInt()}", project.bpm, 110f..130f) { project.bpm = it }
                Knob("Swing", project.swing, 0f..0.4f) { project.swing = it }
                Knob("Delay", project.delayMix, 0f..0.6f) { project.delayMix = it }
                Knob("Feedback", project.delayFeedback, 0f..0.7f) { project.delayFeedback = it }
                OutlinedButton(onClick = {
                    val ok = Store.save(ctx, project)
                    Toast.makeText(ctx, if (ok) "Project saved" else "Save failed", Toast.LENGTH_SHORT).show()
                }) { Text("Save project") }
            }
        }
        items(items = project.tracks, key = { it.id }) { t ->
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Panel).padding(8.dp)) {
                Text(t.name, color = Color.White, fontSize = 14.sp)
                Knob("Volume", t.volume, 0f..1f) { t.volume = it }
                Knob("Pan", t.pan, -1f..1f) { t.pan = it }
                Knob("Pitch ${t.pitch.toInt()}", t.pitch, -12f..12f) { t.pitch = it }
                Knob("Filter", t.cutoff, 0.05f..1f) { t.cutoff = it }
            }
        }
    }
}
