package com.afrohouse.daw

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

const val SR = 44100
const val STEPS = 16
const val PATTERNS = 4
const val SONG_BARS = 16
val PATTERN_NAMES = listOf("A", "B", "C", "D")

class Track(
    val builtin: String?,
    var name: String,
    sample: FloatArray,
    val id: String = java.util.UUID.randomUUID().toString().take(8)
) {
    @Volatile var sample: FloatArray = sample
    var sampleFile: String? = null
    var sampleLabel by mutableStateOf(if (builtin != null) "built-in" else "imported")
    val steps = mutableStateListOf<Boolean>().apply { repeat(PATTERNS * STEPS) { add(false) } }
    var volume by mutableFloatStateOf(0.8f)
    var pan by mutableFloatStateOf(0f)
    var pitch by mutableFloatStateOf(0f)   // semitones, -12..12
    var cutoff by mutableFloatStateOf(1f)  // 1 = fully open low-pass
    var mute by mutableStateOf(false)
    var solo by mutableStateOf(false)

    fun setPattern(p: Int, on: List<Int>) {
        for (i in 0 until STEPS) steps[p * STEPS + i] = i in on
    }
}

class Project {
    var bpm by mutableFloatStateOf(122f)
    var swing by mutableFloatStateOf(0.15f)
    var delayMix by mutableFloatStateOf(0.18f)
    var delayFeedback by mutableFloatStateOf(0.4f)
    var songMode by mutableStateOf(false)
    var editPattern by mutableIntStateOf(0)
    val tracks = mutableStateListOf<Track>()
    val arrangement = mutableStateListOf<Int>().apply { repeat(SONG_BARS) { add(-1) } }

    fun resetArrangement() {
        val d = listOf(0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 3, 3, 3, 3, 3, 3)
        for (i in 0 until SONG_BARS) arrangement[i] = d[i]
    }

    companion object {
        fun afroHouseDemo() = Project().apply {
            fun add(name: String, vol: Float, pan: Float, pats: Map<Int, List<Int>>) {
                val t = Track(name, name, Synth.byName(name))
                t.volume = vol; t.pan = pan
                pats.forEach { (p, on) -> t.setPattern(p, on) }
                tracks += t
            }
            val all = (0 until 16).toList()
            add("Kick", 0.95f, 0f, mapOf(0 to listOf(0, 4, 8, 12), 2 to listOf(0, 4, 8, 12), 3 to listOf(0, 4, 8, 12)))
            add("Clap", 0.7f, 0.1f, mapOf(0 to listOf(4, 12), 2 to listOf(4, 12, 14, 15), 3 to listOf(4, 12)))
            add("Closed Hat", 0.45f, -0.2f, mapOf(0 to listOf(2, 6, 10, 14), 1 to listOf(2, 6, 10, 14), 2 to listOf(2, 6, 10, 14, 15), 3 to listOf(2, 6, 10, 14)))
            add("Open Hat", 0.4f, 0.2f, mapOf(0 to listOf(6, 14), 2 to listOf(14), 3 to listOf(6, 10, 14)))
            add("Shaker", 0.3f, 0.3f, mapOf(0 to all, 1 to all, 2 to all, 3 to all))
            add("Conga", 0.6f, -0.35f, mapOf(0 to listOf(3, 7, 10, 15), 1 to listOf(3, 7, 10, 15), 2 to listOf(3, 7, 10, 15), 3 to listOf(0, 3, 7, 10, 12, 15)))
            add("Rim", 0.4f, 0.4f, mapOf(0 to listOf(5, 13), 1 to listOf(5, 13), 3 to listOf(5, 9, 13)))
            add("Bass", 0.8f, 0f, mapOf(0 to listOf(2, 3, 6, 10, 11, 14), 2 to listOf(2, 6, 10, 14), 3 to listOf(2, 3, 6, 10, 11, 14)))
            add("Stab", 0.45f, 0.05f, mapOf(0 to listOf(3, 10), 1 to listOf(0, 6, 10), 2 to listOf(3), 3 to listOf(3, 10, 13)))
            resetArrangement()
        }
    }
}
