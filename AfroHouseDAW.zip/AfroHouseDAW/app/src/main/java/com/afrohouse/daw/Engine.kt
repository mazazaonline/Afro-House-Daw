package com.afrohouse.daw

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Step-sequencer mixer with pitch, per-voice low-pass, and a dotted-eighth ping-pong delay.
 * Same code drives live playback and offline export.
 */
class Renderer(private val p: Project, private val forceSong: Boolean? = null) {
    private class Voice(val data: FloatArray, var pos: Double, val rate: Double, val gl: Float, val gr: Float, val a: Float) {
        var lp = 0f
    }

    private val voices = ArrayList<Voice>()
    private var pos = 0L
    private var stepCounter = 0L
    private var nextStart = 0.0
    @Volatile var currentStep = -1; private set
    @Volatile var currentBar = -1; private set
    var triggering = true

    private val dBuf = 2 * SR
    private val dl = FloatArray(dBuf)
    private val dr = FloatArray(dBuf)
    private var dw = 0

    fun render(out: FloatArray, frames: Int) {
        val bpm = p.bpm
        val spf = SR * 60.0 / bpm / 4.0
        val swing = p.swing
        val delayFrames = (SR * 60.0 / bpm * 0.75).toInt().coerceIn(1, dBuf - 1)
        val mix = p.delayMix
        val fb = p.delayFeedback
        val song = forceSong ?: p.songMode
        val anySolo = p.tracks.any { it.solo }

        for (n in 0 until frames) {
            if (triggering && pos >= nextStart) {
                val s = (stepCounter % STEPS).toInt()
                val bar = (stepCounter / STEPS).toInt()
                val arrLen = p.arrangement.size
                val pat = if (song) p.arrangement[bar % arrLen] else p.editPattern
                currentStep = s
                currentBar = if (song) bar % arrLen else 0
                if (pat >= 0) {
                    for (t in p.tracks) {
                        if (!t.steps[pat * STEPS + s] || t.mute || (anySolo && !t.solo)) continue
                        val ang = (t.pan.coerceIn(-1f, 1f) + 1f) * PI.toFloat() / 4f
                        val rate = Math.pow(2.0, t.pitch / 12.0)
                        val c = t.cutoff.coerceIn(0.02f, 1f)
                        if (voices.size < 128) {
                            voices += Voice(t.sample, 0.0, rate, cos(ang) * t.volume, sin(ang) * t.volume, c * c)
                        }
                    }
                }
                stepCounter++
                nextStart = stepCounter * spf + if (stepCounter % 2 == 1L) swing * spf else 0.0
            }

            var l = 0f
            var r = 0f
            val iter = voices.iterator()
            while (iter.hasNext()) {
                val v = iter.next()
                val i0 = v.pos.toInt()
                if (i0 >= v.data.size - 1) { iter.remove(); continue }
                val fr = (v.pos - i0).toFloat()
                val x = v.data[i0] + (v.data[i0 + 1] - v.data[i0]) * fr
                v.lp += v.a * (x - v.lp)
                l += v.lp * v.gl
                r += v.lp * v.gr
                v.pos += v.rate
            }

            val rp = (dw - delayFrames + dBuf) % dBuf
            val dlv = dl[rp]
            val drv = dr[rp]
            dl[dw] = l + drv * fb
            dr[dw] = r + dlv * fb
            dw = (dw + 1) % dBuf
            val outL = l + dlv * mix
            val outR = r + drv * mix

            out[n * 2] = Math.tanh((outL * 0.7f).toDouble()).toFloat()
            out[n * 2 + 1] = Math.tanh((outR * 0.7f).toDouble()).toFloat()
            pos++
        }
    }
}

class Player(private val project: Project) {
    @Volatile private var running = false
    @Volatile private var renderer: Renderer? = null
    private var thread: Thread? = null
    val isPlaying: Boolean get() = running
    val currentStep: Int get() = if (running) renderer?.currentStep ?: -1 else -1
    val currentBar: Int get() = if (running) renderer?.currentBar ?: -1 else -1

    fun start() {
        if (running) return
        running = true
        val r = Renderer(project); renderer = r
        thread = Thread {
            val min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
            val at = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setBufferSizeInBytes(maxOf(min, 4096 * 2 * 4))
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
            at.play()
            val buf = FloatArray(512 * 2)
            while (running) { r.render(buf, 512); at.write(buf, 0, buf.size, AudioTrack.WRITE_BLOCKING) }
            at.stop(); at.release()
        }.also { it.priority = Thread.MAX_PRIORITY; it.start() }
    }

    fun stop() { running = false; thread?.join(500); thread = null }
}
