package com.afrohouse.daw

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

object Store {
    private fun mainFile(ctx: Context) = File(ctx.filesDir, "project.json")

    private fun writePcm(f: File, data: FloatArray) {
        val bb = ByteBuffer.allocate(data.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (x in data) bb.putShort((x.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
        f.writeBytes(bb.array())
    }

    private fun readPcm(f: File): FloatArray {
        val sb = ByteBuffer.wrap(f.readBytes()).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val out = FloatArray(sb.remaining())
        for (i in out.indices) out[i] = sb.get() / 32768f
        return out
    }

    fun save(ctx: Context, p: Project): Boolean {
        return try {
            val o = JSONObject()
            o.put("bpm", p.bpm.toDouble())
            o.put("swing", p.swing.toDouble())
            o.put("delayMix", p.delayMix.toDouble())
            o.put("delayFb", p.delayFeedback.toDouble())
            o.put("songMode", p.songMode)
            o.put("editPattern", p.editPattern)
            o.put("arr", JSONArray(p.arrangement.toList()))
            val ta = JSONArray()
            for (t in p.tracks) {
                val j = JSONObject()
                j.put("id", t.id)
                j.put("name", t.name)
                val b = t.builtin
                if (b != null) {
                    j.put("builtin", b)
                } else {
                    var fn = t.sampleFile
                    if (fn == null) {
                        fn = "smp_" + t.id + "_" + System.currentTimeMillis() + ".pcm"
                        writePcm(File(ctx.filesDir, fn), t.sample)
                        t.sampleFile = fn
                    }
                    j.put("sampleFile", fn)
                    j.put("label", t.sampleLabel)
                }
                j.put("vol", t.volume.toDouble())
                j.put("pan", t.pan.toDouble())
                j.put("pitch", t.pitch.toDouble())
                j.put("cutoff", t.cutoff.toDouble())
                j.put("mute", t.mute)
                j.put("solo", t.solo)
                j.put("steps", t.steps.joinToString("") { if (it) "1" else "0" })
                ta.put(j)
            }
            o.put("tracks", ta)
            mainFile(ctx).writeText(o.toString())
            true
        } catch (e: Exception) {
            false
        }
    }

    fun load(ctx: Context): Project? {
        return try {
            val f = mainFile(ctx)
            if (!f.exists()) return null
            val o = JSONObject(f.readText())
            val p = Project()
            p.bpm = o.getDouble("bpm").toFloat()
            p.swing = o.getDouble("swing").toFloat()
            p.delayMix = o.getDouble("delayMix").toFloat()
            p.delayFeedback = o.getDouble("delayFb").toFloat()
            p.songMode = o.getBoolean("songMode")
            p.editPattern = o.getInt("editPattern")
            val arr = o.getJSONArray("arr")
            for (i in 0 until minOf(arr.length(), SONG_BARS)) p.arrangement[i] = arr.getInt(i)
            val ta = o.getJSONArray("tracks")
            for (i in 0 until ta.length()) {
                val j = ta.getJSONObject(i)
                val b: String? = if (j.has("builtin")) j.getString("builtin") else null
                val sample = if (b != null) Synth.byName(b) else readPcm(File(ctx.filesDir, j.getString("sampleFile")))
                val t = Track(b, j.getString("name"), sample, j.getString("id"))
                if (b == null) {
                    t.sampleFile = j.getString("sampleFile")
                    t.sampleLabel = j.optString("label", "imported")
                }
                t.volume = j.getDouble("vol").toFloat()
                t.pan = j.getDouble("pan").toFloat()
                t.pitch = j.getDouble("pitch").toFloat()
                t.cutoff = j.getDouble("cutoff").toFloat()
                t.mute = j.getBoolean("mute")
                t.solo = j.getBoolean("solo")
                val s = j.getString("steps")
                for (k in 0 until minOf(s.length, t.steps.size)) t.steps[k] = s[k] == '1'
                p.tracks += t
            }
            if (p.tracks.isEmpty()) null else p
        } catch (e: Exception) {
            null
        }
    }
}
